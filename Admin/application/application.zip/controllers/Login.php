<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login controller class
 */
class Login extends CI_Controller{
    
    function __construct(){
        parent::__construct();
       // $this->load->model('Product_Model');
    }
    
    public function index($msg = NULL){
        // Load our view to be displayed
        // to the user
        $data['msg'] = $msg;
        $this->load->view('Login/login',$data);
    }

    public function registerUser(){
        $data['main_content'] = 'User/AddUser';
        $this->load->view('admin/master', $data);
    }

    public function Save(){
        $status = "";
        $msg = "";

        $fulname = $this->security->xss_clean($this->input->post('txtfName'));
        $username = $this->security->xss_clean($this->input->post('txtuName'));
        $usertype = $this->security->xss_clean($this->input->post('txtuType'));
        $password = $this->security->xss_clean($this->input->post('txtPassword'));
       
        $file_id = $this->Product_Model->SaveUser($fulname,$username,$usertype,$password);

        if ($file_id !== null) {
            $status = "success";
            $msg = "Product successfully deleted";
        } else {
            $status = "error";
            $msg = "Something went wrong when deleting the center, please try again.";
        }
        echo json_encode(array('status' => $status, 'msg' => $msg));
    }
    
    public function process(){
        // Load the model
        $this->load->model('Login_model');


        $uName = $this->security->xss_clean($this->input->post('txtusername'));
        $password = $this->security->xss_clean($this->input->post('txtpassword'));


        // Validate the user can login
        $result = $this->Login_model->validate($uName,$password);

        // Now we verify the result
        if(! $result){
            // If user did not validate, then show them login page again
            $msg = '<font color=red>Invalid username and/or password.</font><br />';
        
            // $data['msg'] = $msg;
                $this->index($msg);
            
        }else{
            // If user did validate, 
            // Send them to members area
            redirect('Home');
        }        
    }
}

